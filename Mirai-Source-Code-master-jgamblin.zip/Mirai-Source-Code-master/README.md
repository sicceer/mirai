# Mirai BotNet
Leaked Linux.Mirai Source Code for Research/IoT Development Purposes

Uploaded for research purposes and so we can develop IoT and such.

See "ForumPost.txt" or [ForumPost.md](ForumPost.md) for the post in which it
leaks, if you want to know how it is all set up and the likes.

## Requirements
* gcc
* golang
* electric-fence
* mysql-server
* mysql-client

## Credits

[Anna-senpai](https://hackforums.net/showthread.php?tid=5420472)

## Disclaimer

This repository is for academic purposes, the use of this software is your
responsibility.
